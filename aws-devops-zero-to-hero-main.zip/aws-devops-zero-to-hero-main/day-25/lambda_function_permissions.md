Below are the permissions that you need to grant to the role that executes the lambda function used in the project.

![Screenshot 2023-08-10 at 11 41 54 PM](https://github.com/iam-veeramalla/aws-devops-zero-to-hero/assets/43399466/99e08bdb-17aa-4962-a96a-3cecdb99ee8d)
